package net.infy.vra;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import net.infy.vra.repository.VehicleRepository;

@SpringBootApplication

public class VehicleRentalApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(VehicleRentalApplication.class, args);
	}

	@Autowired
	private VehicleRepository vehicleRepository;
	
	@Override
	public void run(String... args) throws Exception {
		
		/*
		 * Student student1 = new Student("Ramesh", "Fadatare", "ramesh@gmail.com");
		 * vehicleRepository.save(student1);
		 * 
		 * Student student2 = new Student("Sanjay", "Jadhav", "sanjay@gmail.com");
		 * vehicleRepository.save(student2);
		 * 
		 * Student student3 = new Student("tony", "stark", "tony@gmail.com");
		 * vehicleRepository.save(student3);
		 */
		
	}

}
