package net.infy.vra.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import net.infy.vra.entity.Vehicle;
import net.infy.vra.service.VehicleService;

@Controller
public class VehicleController {
	
	private VehicleService vehicleService;

	public VehicleController(VehicleService vehicleService) {
		super();
		this.vehicleService = vehicleService;
	}
	
	// handler method to handle list students and return mode and view
	@GetMapping("/vehicles")
	public String listStudents(Model model) {
		model.addAttribute("vehicles", vehicleService.getAllStudents());
		return "vehicles";
	}
	
	@GetMapping("/vehicles/new")
	public String createStudentForm(Model model) {
		
		// create student object to hold student form data
		Vehicle student = new Vehicle();
		model.addAttribute("vehicle", student);
		return "create_vehicle";
		
	}
	
	@PostMapping("/vehicles")
	public String saveStudent(@ModelAttribute("vehicle") Vehicle student) {
		vehicleService.saveStudent(student);
		return "redirect:/vehicles";
	}
	
	@GetMapping("/students/edit/{id}")
	public String editStudentForm(@PathVariable Long id, Model model) {
		model.addAttribute("vehicle", vehicleService.getStudentById(id));
		return "edit_vehicle";
	}

	@PostMapping("/vehicles/{id}")
	public String updateStudent(@PathVariable Long id,
			@ModelAttribute("vehicle") Vehicle student,
			Model model) {
		
		// get student from database by id
		Vehicle existingStudent = vehicleService.getStudentById(id);
		existingStudent.setId(id);
		existingStudent.setFirstName(student.getFirstName());
		existingStudent.setLastName(student.getLastName());
		existingStudent.setEmail(student.getEmail());
		
		// save updated student object
		vehicleService.updateStudent(existingStudent);
		return "redirect:/students";		
	}
	
	// handler method to handle delete student request
	
	@GetMapping("/students/{id}")
	public String deleteStudent(@PathVariable Long id) {
		vehicleService.deleteStudentById(id);
		return "redirect:/students";
	}
	
}
