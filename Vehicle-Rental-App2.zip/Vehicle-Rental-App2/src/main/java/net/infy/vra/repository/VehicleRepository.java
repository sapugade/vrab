package net.infy.vra.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import net.infy.vra.entity.Vehicle;

public interface VehicleRepository extends JpaRepository<Vehicle, Long>{

}
