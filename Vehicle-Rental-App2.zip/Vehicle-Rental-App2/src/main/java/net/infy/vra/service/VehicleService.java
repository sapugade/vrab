package net.infy.vra.service;

import java.util.List;

import net.infy.vra.entity.Vehicle;

public interface VehicleService {
	List<Vehicle> getAllStudents();
	
	Vehicle saveStudent(Vehicle student);
	
	Vehicle getStudentById(Long id);
	
	Vehicle updateStudent(Vehicle student);
	
	void deleteStudentById(Long id);
}
