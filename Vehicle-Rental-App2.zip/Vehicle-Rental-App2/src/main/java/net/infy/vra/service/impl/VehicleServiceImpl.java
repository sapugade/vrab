package net.infy.vra.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import net.infy.vra.entity.Vehicle;
import net.infy.vra.repository.VehicleRepository;
import net.infy.vra.service.VehicleService;

@Service
public class VehicleServiceImpl implements VehicleService{

	private VehicleRepository vehicleRepository;
	
	public VehicleServiceImpl(VehicleRepository vehicleRepository) {
		super();
		this.vehicleRepository = vehicleRepository;
	}

	@Override
	public List<Vehicle> getAllStudents() {
		return vehicleRepository.findAll();
	}

	@Override
	public Vehicle saveStudent(Vehicle student) {
		return vehicleRepository.save(student);
	}

	@Override
	public Vehicle getStudentById(Long id) {
		return vehicleRepository.findById(id).get();
	}

	@Override
	public Vehicle updateStudent(Vehicle student) {
		return vehicleRepository.save(student);
	}

	@Override
	public void deleteStudentById(Long id) {
		vehicleRepository.deleteById(id);	
	}

}
